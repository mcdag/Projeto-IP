package Repositorios;

import ClassesBasicas.Produto;
import Interfaces.InterfaceProduto;

public class RepositorioListaProduto implements InterfaceProduto {
	private Produto objetoProduto;
	private RepositorioListaProduto proximo;

	public RepositorioListaProduto() {
		this.objetoProduto = null;
		this.proximo = null;
	}

	public boolean procurar(int codigoProduto) {
		if (this.objetoProduto == null) {
			return false;
		} else {
			if (this.objetoProduto.getCodigo() == codigoProduto) {
				return true;
			} else {
				return this.proximo.procurar(codigoProduto);
			}
		}
	}

	public void inserir(Produto item) {
		if (this.objetoProduto == null) {
			this.objetoProduto = item;
			this.proximo = new RepositorioListaProduto();
		} else {
			this.proximo.inserir(item);
		}
	}

	public void remover(int codigoProduto) {
		if (codigoProduto == this.objetoProduto.getCodigo()) {
			this.objetoProduto = this.proximo.objetoProduto;
			this.proximo = this.proximo.proximo;
		} else {
			this.proximo.remover(codigoProduto);
		}

	}

	public void atualizarNome(int codigoProduto, String novoNome) {
		if (codigoProduto == this.objetoProduto.getCodigo()) {
			this.objetoProduto.setNome(novoNome);
		} else {
			this.proximo.atualizarNome(codigoProduto, novoNome);
		}
	}

	public void atualizarPreco(int codigoProduto, Double novoPreco) {
		if (codigoProduto == this.objetoProduto.getCodigo()) {
			this.objetoProduto.setPreco(novoPreco);
		} else {
			this.proximo.atualizarPreco(codigoProduto, novoPreco);
		}
	}

}
