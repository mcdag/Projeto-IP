package Repositorios;

import ClassesBasicas.Funcionario;
import Interfaces.InterfacePessoaFuncionario;
import Excecoes.FuncionarioNaoEncontradoException;

public class RepositorioListaPessoaFuncionario implements InterfacePessoaFuncionario {
	private Funcionario funcionario;
	private RepositorioListaPessoaFuncionario proximo;

	public RepositorioListaPessoaFuncionario() {
		this.funcionario = null;
		this.proximo = null;
	}

	public void inserirPessoaFuncionario(Funcionario funcionario) {
		if (this.proximo == null) {
			this.funcionario = funcionario;
			this.proximo = new RepositorioListaPessoaFuncionario();
		} else {
			this.proximo.inserirPessoaFuncionario(funcionario);
		}
	}

	public void removerPessoaFuncionario(Funcionario funcionario) throws FuncionarioNaoEncontradoException {
		if (this.proximo != null && funcionario.getCpfPessoa().equals(this.funcionario.getCpfPessoa())) {
			this.funcionario = this.proximo.funcionario;
			this.proximo = this.proximo.proximo;
		} else if (this.proximo != null) {
			this.proximo.removerPessoaFuncionario(funcionario);
		} else {
			throw new FuncionarioNaoEncontradoException();
		}
	}

	public boolean temPessoaFuncionario(Funcionario funcionario) {
		if (this.proximo != null && this.funcionario.getCpfPessoa().equals(funcionario.getCpfPessoa())) {
			return true;
		} else if (this.proximo != null) {
			this.proximo.temPessoaFuncionario(funcionario);
		}
		return false;
	}

	public Funcionario buscarPessoaFuncionario(String cpf , int i) throws FuncionarioNaoEncontradoException {
		if (this.proximo != null && this.funcionario.getCpfPessoa().equals(cpf)) {
			return this.funcionario;
		} else if (this.proximo != null) {
			return this.proximo.buscarPessoaFuncionario(cpf , 0);
		} else {
			throw new FuncionarioNaoEncontradoException();
		}
	}

	public void atualizarNomePessoaFuncionario(String nome, String cpf) throws FuncionarioNaoEncontradoException {
		Funcionario funcionario = buscarPessoaFuncionario(cpf , 0);
		funcionario.setNomePessoa(nome);
	}

	public void atualizarSalarioPessoaFuncionario(double salario, String cpf) throws FuncionarioNaoEncontradoException {
		Funcionario funcionario = buscarPessoaFuncionario(cpf , 0);
		funcionario.setSalarioFuncionario(salario);
	}

}