package Repositorios;

import ClassesBasicas.Entrega;
import Interfaces.InterfaceEntrega;
import Excecoes.*;

public class RepositorioArrayEntrega implements InterfaceEntrega {
	private Entrega[] entrega;
	private int indice;

	public RepositorioArrayEntrega() {
		this.entrega = new Entrega[50];
		this.indice = 0;
	}

	public void inserirEntrega(Entrega entrega) throws EntregaJaCadastradaException {

	}

	public void removerEntrega(Entrega entrega) throws EntregaNaoEncontradaException {

	}

	public void atualizarEntrega(Entrega entrega) throws EntregaNaoEncontradaException {

	}

	public boolean procurarEntrega(Entrega entrega) {

		return false;
	}

}
