package Repositorios;

import Interfaces.InterfaceFornecedor;
import ClassesBasicas.Fornecedor;
import Excecoes.CnpjInvalidoException;
import Excecoes.FornecedorJaCadastradoException;
import Excecoes.FornecedorNaoEncontradoException;

public class RepositorioListaFornecedor implements InterfaceFornecedor {
	private Fornecedor fornecedor;// elemento da lista
	private RepositorioListaFornecedor proximo;// referencia

	// construtor
	public RepositorioListaFornecedor() {
		this.fornecedor = null;
		this.proximo = null;
	}

	// inserindo fornecedor na lista
	public void inserir(Fornecedor fornecedor) throws FornecedorJaCadastradoException {
		if (this.fornecedor == null) {
			this.fornecedor = fornecedor;
			this.proximo = new RepositorioListaFornecedor();
		} else {
			if (this.fornecedor.getCNPJ().equals(fornecedor.getCNPJ())) {
				throw new FornecedorJaCadastradoException(fornecedor.getCNPJ());
			}
			this.proximo.inserir(fornecedor);
		}
	}// end - inserir

	// atualizando dados do fornecedor na lista
	public void atualizar(Fornecedor fornecedor) {// parametro de mudanca ->
		// nome; parametro fixo -> // CNPJ
		if (this.fornecedor.getCNPJ().equals(fornecedor.getCNPJ())) {
			this.fornecedor = fornecedor;
		} else {
			this.proximo.atualizar(fornecedor);
		}
	}// end - atualizar

	// removendo fornecedor da lista
	public void remover(String CNPJ) throws CnpjInvalidoException {// usuario procura pelo CNPJ da empresa
		if (CNPJ.length() <= 18) {
			if (this.fornecedor.getCNPJ().equals(CNPJ)) {
				this.fornecedor = this.proximo.fornecedor;
				this.proximo = this.proximo.proximo;
			} else {
				this.proximo.remover(CNPJ);
			}
		} else {
			throw new CnpjInvalidoException(CNPJ);// lancando a excecao
		}
	}// end - remover

	// procurando o fornecedor na lista
	public boolean procurar(String CNPJ) throws FornecedorNaoEncontradoException {
		if (this.fornecedor.getCNPJ() == null) {

			throw new FornecedorNaoEncontradoException(CNPJ);// lancando a excecao

		} else {
			if (this.fornecedor.getCNPJ().equals(CNPJ)) {
				return true;
			} else {
				return this.proximo.procurar(CNPJ);
			}
		}
	}// end - procurar
}// end - listaRepositorio
