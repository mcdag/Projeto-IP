package Repositorios;

import ClassesBasicas.Produto;
import Interfaces.InterfaceProduto;
import Excecoes.*;

public class RepositorioArrayProduto {
	private Produto[] arrayProduto;
	private int indice;

	public RepositorioArrayProduto() {
		this.arrayProduto = new Produto[30];
		this.indice = 0;
	}

	public int procurar(int codigoProduto) {
		Produto item = arrayProduto[this.indice];
		if (this.indice < arrayProduto.length && item.getCodigo() == codigoProduto) {
			return this.indice;
		} else if (this.indice < arrayProduto.length && item.getCodigo() != codigoProduto) {
			this.indice++;
			return procurar(codigoProduto);
		} else {
			return -1;
		}
	}

	public void inserir(Produto item) throws ProdutoJaCadastradoException {
		int n = procurar(item.getCodigo());
		if (n != -1) {
			throw new ProdutoJaCadastradoException(item.getCodigo());
		} else {
			if (n == this.arrayProduto.length - 1) {
				Produto[] novaArrayProduto = new Produto[this.arrayProduto.length * 2];
				for (int i = 0; i < this.arrayProduto.length - 1; i++) {
					novaArrayProduto[i] = this.arrayProduto[i];
				}
				this.arrayProduto = novaArrayProduto;
				this.inserir(item);
			}
			this.arrayProduto[n] = item;
		}
	}

	public void remover(int codigoProduto) throws ProdutoNaoEncontradoException {
		int n = procurar(codigoProduto);
		if (n == -1) {
			throw new ProdutoNaoEncontradoException(codigoProduto);
		} else {
			arrayProduto[n] = null;
		}
	}

	public void atualizarNome(int codigoProduto, String novoNome) throws ProdutoNaoEncontradoException {
		int n = procurar(codigoProduto);
		if (n == -1) {
			throw new ProdutoNaoEncontradoException(codigoProduto);
		} else {
			arrayProduto[n].setNome(novoNome);
		}
	}

	public void atualizarPreco(int codigoProduto, Double novoPreco) throws ProdutoNaoEncontradoException {
		int n = procurar(codigoProduto);
		if (n == -1) {
			throw new ProdutoNaoEncontradoException(codigoProduto);
		} else {
			arrayProduto[n].setPreco(novoPreco);
		}
	}

}
