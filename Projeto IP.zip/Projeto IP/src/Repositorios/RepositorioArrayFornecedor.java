package Repositorios;

import Interfaces.InterfaceFornecedor;
import ClassesBasicas.Fornecedor;
import Excecoes.CnpjInvalidoException;
import Excecoes.FornecedorJaCadastradoException;
import Excecoes.FornecedorNaoEncontradoException;

public class RepositorioArrayFornecedor implements InterfaceFornecedor {
    // declarando o array
    private Fornecedor[] arrayFornecedor;
    private int tamInicial;

    // construtor
    public RepositorioArrayFornecedor() {
   	 // inicializando as variaveis
   	 tamInicial = 1000;
   	 arrayFornecedor = new Fornecedor[tamInicial];
    }

    public void aumentaVetor() {
   	 Fornecedor[] arrayFornecedor2 = new Fornecedor[2 * tamInicial];

   	 for (int i = 0; i < tamInicial; i++) {
   		 arrayFornecedor2[i] = arrayFornecedor[i];
   	 }
   	 tamInicial = 2 * tamInicial;
   	 arrayFornecedor = arrayFornecedor2;// apontador antigo aponta p novo array
    }// end - aumentar - vetor

    public void inserir(Fornecedor fornecedor) throws FornecedorJaCadastradoException {// antes de inserir, temos que
   																					 // verificar se o fornecedor ja
   																			 // esta no    // array
   	 boolean nInseriu = true;
   	 for (int i = 0; i < tamInicial && nInseriu; i++) {
   		 if (arrayFornecedor[i] == null) {
   			 arrayFornecedor[i] = fornecedor;
   			 nInseriu = false;
   		 } // end - if
   		 else {
   			 if (arrayFornecedor[i].getCNPJ().equals(fornecedor.getCNPJ())) {
   				 throw new FornecedorJaCadastradoException(fornecedor.getCNPJ());
   			 } else {
   				 if (i == tamInicial - 1) {
   					 this.aumentaVetor();
   				 } // end - if
   			 }
   		 } // end - else
   	 } // end - for
    }// end - inserir

    public void remover(String CNPJ) throws CnpjInvalidoException {// so podemos remover se o fornecedor estiver no //
   																 // array
   	 boolean nAchouF = true;
   	 for (int i = 0; i < tamInicial && nAchouF; i++) {
   		 if (CNPJ.length() <= 18) {
   			 if (arrayFornecedor[i].getCNPJ().equals(CNPJ)) {
   				 arrayFornecedor[i] = null;
   				 nAchouF = false;
   			 } // end - if
   			 else {
   				 throw new CnpjInvalidoException(CNPJ);
   			 }
   		 } else {
   			 throw new CnpjInvalidoException(CNPJ);
   		 }
   	 } // end - for
    }// end - remover

    public boolean procurar(String CNPJ) throws FornecedorNaoEncontradoException {// procurando o fornecedor pelo CNPJ
   	 int nAchouFornecedor = 0;
   	 for (int i = 0; i < tamInicial; i++) {
   		 if (arrayFornecedor[i].getCNPJ().equals(CNPJ)) {
   			 return true;
   		 } else {
   			 nAchouFornecedor++;
   		 }
   	 }
   	 if (nAchouFornecedor == tamInicial - 1) {
   		 throw new FornecedorNaoEncontradoException(CNPJ);
   	 } else {
   		 return true;
   	 }
    }// end - procurar

    public void atualizar(Fornecedor fornecedor) {// so podemos atualizar a empresa, se a acharmos
   	 // parametro de procura -> CNPJ; parametro de mudanca -> NovoNomeEmpresa
   	 for (int i = 0; i < tamInicial; i++) {
   		 if (arrayFornecedor[i].getCNPJ().equals(fornecedor.getCNPJ())) {
   			 arrayFornecedor[i] = fornecedor;
   		 } // end - if
   	 } // end - for
    }// end - atualizar
}// end - ArrayRepositorio_Fornecedor


