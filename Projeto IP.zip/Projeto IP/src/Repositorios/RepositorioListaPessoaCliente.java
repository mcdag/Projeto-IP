package Repositorios;

import ClassesBasicas.Cliente;
import Excecoes.ClienteNaoEncontradoException;
import Interfaces.InterfacePessoaCliente;

public class RepositorioListaPessoaCliente implements InterfacePessoaCliente {
	private Cliente cliente;
	private RepositorioListaPessoaCliente proximo;

	public RepositorioListaPessoaCliente() {
		this.cliente = null;
		this.proximo = null;
	}

	public void inserirPessoaCliente(Cliente cliente) {
		if (this.proximo == null) {
			this.cliente = cliente;
			this.proximo = new RepositorioListaPessoaCliente();
		} else {
			this.proximo.inserirPessoaCliente(cliente);
		}
	}

	public void removerPessoaCliente(Cliente cliente) throws ClienteNaoEncontradoException {
		if (this.proximo != null && cliente.getCpfPessoa().equals(this.cliente.getCpfPessoa())) {
			this.cliente = this.proximo.cliente;
			this.proximo = this.proximo.proximo;
		} else if (this.proximo != null) {
			this.proximo.removerPessoaCliente(cliente);
		} else {
			throw new ClienteNaoEncontradoException();
		}
	}

	public boolean temPessoaCliente(Cliente cliente) {
		if (this.proximo != null && this.cliente.getCpfPessoa().equals(cliente.getCpfPessoa())) {
			return true;
		} else if (this.proximo != null) {
			this.proximo.temPessoaCliente(cliente);
		}
		return false;
	}

	public Cliente buscarPessoaCliente(String cpf , int i) throws ClienteNaoEncontradoException {
		if (this.proximo != null && this.cliente.getCpfPessoa().equals(cpf)) {
			return this.cliente;
		} else if (this.proximo != null) {
			return this.proximo.buscarPessoaCliente(cpf , 0);
		} else {
			throw new ClienteNaoEncontradoException();
		}
	}

	public void atualizarNomePessoaCliente(String nome, String cpf) throws ClienteNaoEncontradoException {
		Cliente cliente = buscarPessoaCliente(cpf , 0);
		cliente.setNomePessoa(nome);
	}

	public void atualizarEnderecoPessoaCliente(String endereco, String cpf) throws ClienteNaoEncontradoException {
		Cliente cliente = buscarPessoaCliente(cpf , 0);
		cliente.setEnderecoCliente(endereco);
	}
}