package ClassesBasicas;

import Repositorios.RepositorioListaProduto;

public class Fornecedor {
	// classe possui 2 atributos pr�prios e um objeto listaProdutos
	private String CNPJ;
	private String nomeEmpresa;
	private RepositorioListaProduto listaProdutos;

	// construtor
	public Fornecedor() {
		this.CNPJ = null;
		this.nomeEmpresa = null;
		this.listaProdutos = null;
	}// end - construtor

	// metodos permitem alterar/acessar atributos da classe fornecedor no main
	public String getCNPJ() {
		return this.CNPJ;
	}

	public void setCNPJ(String cNPJ) {
		this.CNPJ = cNPJ;
	}

	public String getNomeEmpresa() {
		return this.nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	public RepositorioListaProduto getListaProdutos() {
		return this.listaProdutos;
	}

	public void setListaProdutos(RepositorioListaProduto listaProdutos) {
		this.listaProdutos = listaProdutos;
	}
}// end - fornecedor_class
