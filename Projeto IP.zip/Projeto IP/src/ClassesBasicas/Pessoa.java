package ClassesBasicas;

abstract class Pessoa {
	private String nome;
	private String cpf;

	Pessoa(String nome, String cpf) {
		this.nome = nome;
		this.cpf = cpf;
	}

	public String getNomePessoa() {
		return nome;
	}

	public void setNomePessoa(String nome) {
		this.nome = nome;
	}

	public String getCpfPessoa() {
		return cpf;
	}

	public void setCpfPessoa(String cpf) {
		this.cpf = cpf;
	}

}