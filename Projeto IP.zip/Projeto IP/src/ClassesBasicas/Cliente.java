package ClassesBasicas;

public class Cliente extends Pessoa {
	private String endereco;

	public Cliente(String nome, String cpf, String endereco) {
		super(nome, cpf);
		this.endereco = endereco;
	}

	public String getEnderecoCliente() {
		return this.getEnderecoCliente();
	}

	public void setEnderecoCliente(String endereco) {
		this.endereco = endereco;
	}
}
