package Main;

import java.util.*;
import Negocios.*;
import Repositorios.*;
import ClassesBasicas.*;
import Excecoes.*;
import Fachada.*;

public class Main {

	public static void main(String[] args) throws FornecedorJaCadastradoException {

		Scanner in = new Scanner(System.in);
		// declarando variavel que determinara qual sera o tipo de acesso no programa
		String tipoAcesso = "";

		System.out.println("***************************************************************************");
		System.out.println("                  	      BEM VINDO(A) AO MENU                             	");
		System.out.println("***************************************************************************");
		System.out.println("");
		System.out.println("Escolha uma acesso -> Funcionario(Fu)/Produto(Pr)/Cliente(C)/Fornecedor(Fo)/Entrega(E): ");
		tipoAcesso = in.next();

		if (tipoAcesso.equalsIgnoreCase("Fu")) {

		} // end - employee

		else if (tipoAcesso.equalsIgnoreCase("Pr")) {
			Fachada acesso = new Fachada(tipoAcesso);
			try {
				acesso.inserir(new Produto("nescau", 001, 12.50));
				acesso.inserir(new Produto("leite ninho", 002, 26.00));
				acesso.inserir(new Produto("cafe", 003, 06.20));
				acesso.inserir(new Produto("macarrao", 004, 02.40));
				acesso.inserir(new Produto("arroz", 005, 04.15));
				acesso.inserir(new Produto("feijao", 006, 09.25));
				acesso.inserir(new Produto("file", 007, 32.27));
				acesso.inserir(new Produto("peito de frango", 010, 16.70));
				acesso.inserir(new Produto("contra-file", 011, 14.62));
				acesso.inserir(new Produto("sal", 012, 01.00));
				acesso.inserir(new Produto("acucar", 013, 03.11));
				acesso.inserir(new Produto("molho de tomate", 014, 02.80));
				acesso.inserir(new Produto("pesto", 015, 12.00));
				acesso.inserir(new Produto("pao de caixa", 016, 03.31));
				acesso.inserir(new Produto("coador de papel", 017, 03.08));
				acesso.inserir(new Produto("cerveja guinness", 100, 32.00));
				acesso.inserir(new Produto("cerveja heineken", 101, 04.00));
				acesso.inserir(new Produto("amendoim", 102, 06.29));
				acesso.inserir(new Produto("copo descartavel", 103, 05.50));
				acesso.inserir(new Produto("chocolate lacta", 104, 06.49));
				acesso.inserir(new Produto("nissin miojo", 105, 00.70));
			} catch (ProdutoJaCadastradoException PJC) {
				System.out.println(PJC.getMessage());
//			} catch (OpcaoInvalidaException OI) {
//				System.out.println(OI.getMessage());
			} finally {
				System.out.println("----------------- FIM DO TESTE 1 ----------------- ");
				System.out.println("");
			}

			try {
				acesso.remover(105);
				acesso.remover(101);
				acesso.remover(016);
				acesso.remover(007);
				acesso.remover(556);
//			} catch (OpcaoInvalidaException OI) {
//				System.out.println(OI.getMessage());
			} catch (ProdutoNaoEncontradoException PNE) {
				System.out.println(PNE.getMessage());
			} finally {
				System.out.println("----------------- FIM DO TESTE 2 ----------------- ");
				System.out.println("");
			}
			try {
				acesso.atualizarNome(001, "nescau light");
				acesso.atualizarNome(004, "talharim");
				acesso.atualizarNome(005, "arroz tio joao");
				acesso.atualizarNome(102, "amendoim japones");
				acesso.atualizarNome(101, "heineken");
				acesso.atualizarPreco(012, 01.15);
				acesso.atualizarPreco(013, 02.90);
				acesso.atualizarPreco(014, 03.00);
				acesso.atualizarPreco(100, 29.90);
				acesso.atualizarPreco(101, 03.50);
				acesso.atualizarPreco(515, 10.16);
//			} catch (OpcaoInvalidaException OI) {
//				System.out.println(OI.getMessage());
			} catch (ProdutoNaoEncontradoException PNE) {
				System.out.println(PNE.getMessage());
			} finally {
				System.out.println("----------------- FIM DO TESTE 3 ----------------- ");
				System.out.println("");
			}

		} // end - product

		else if (tipoAcesso.equalsIgnoreCase("C")) {

		} // end - client

		else if (tipoAcesso.equalsIgnoreCase("Fo")) {

			// variaveis relativas aos DADOS do fornecedor
			String empresaFornecedor = "", CNPJ = "";
			RepositorioListaProduto lP;
			String nomeProduto = "";
			Integer codigoProduto = 0;
			Double precoProduto = 0.0;
			Produto produto = new Produto(nomeProduto, codigoProduto, precoProduto);// produto a ser inserido no
																					// repositorio Lista Produto
			String[] arrayProdutos;
			int tamListaProdutos = 0;

			// variaveis relativas ao tipo de repositorio que sera escolhido (Array/Lista)
			String tipoRepositorio = "";

			// variavel relativa a operacao a ser realizada
			int operacao = 0;

			System.out.println("Fornecedor, escolha uma op��o abaixo(1/2/3/4): ");
			/*
			 * Para inserir o o fornecedor na lista/array do mercado, precisamos verifica se
			 * ele ja esta cadastrado
			 */
			System.out.println("1)Cadastro ");
			/*
			 * Para alterar dados do fornecedor na lista/array do mercado, precisamos
			 * verificar se ele ja esta cadastrado
			 */
			System.out.println("2)Alterar dados ");
			/*
			 * Para remover o fornecedor da lista/array do mercado, precisamos verificar se
			 * ele ja esta cadastrado
			 */
			System.out.println("3)Cancelar Contrato");

			operacao = in.nextInt();
			in.nextLine();

			// CADASTRO FORNECEDOR
			if (operacao == 1) {
				// fornecendo dados do fornecedor para o cadastro
				System.out.print("Informe os dados do Fornecedor: " + "\n" + "1)CNPJ: ");
				Fornecedor fornecedor1 = new Fornecedor();
				CNPJ = in.nextLine();

				System.out.println("2)Nome da empresa: ");
				empresaFornecedor = in.nextLine();

				System.out.println("3)Linha de produtos(Ao final da lista de produtos, digite FIM): ");// pode gerar
				System.out.println("**************************************************************************"); // erro
				System.out.println("                         	Informe ");// pode gerar erro
				System.out.println("**************************************************************************");

				System.out.print("a)Nome do Produto: ");
				nomeProduto = in.nextLine();

				System.out.print("b)Codigo do Produto: ");
				codigoProduto = Integer.parseInt(in.nextLine());

				System.out.print("c)Pre�o do Produto: ");
				precoProduto = Double.parseDouble(in.nextLine());

				// inserindo os atributos do produto a ser inserido na lista de produtos
				while (!nomeProduto.equalsIgnoreCase("FIM")) {
					produto.setNome(nomeProduto);
					produto.setCodigo(codigoProduto);
					produto.setPreco(precoProduto);
					System.out.println("**************************************************************************");
					System.out.print("a)Nome do Produto: ");
					nomeProduto = in.nextLine();
					if (!nomeProduto.equalsIgnoreCase("FIM") && !nomeProduto.equalsIgnoreCase(" ")) {
						System.out.print("b)Codigo do Produto: ");
						codigoProduto = Integer.parseInt(in.nextLine());

						System.out.println("c)Pre�o do Produto: ");
						precoProduto = Double.parseDouble(in.nextLine());
					} else {
						System.out
								.println("**************************************************************************");
						System.out.println("                      	FIM DA LISTA DE PRODUTOS");
						System.out
								.println("**************************************************************************");
					}

				} // end - while

				// verificando quantos produtos a empresa trabalha

				// inserindo os dados do fornecedor
				fornecedor1.setCNPJ(CNPJ);
				fornecedor1.setNomeEmpresa(empresaFornecedor);

				// tentando inserir o fornecedor no Repositorio do tipo Lista
				NegocioFornecedor nF = new NegocioFornecedor(tipoRepositorio);

				// antes de inserir o fornecedor, temos que verificar se ele ja existe na Lista

			}

			// // fornecendo dados do fornecedor para o cadastro
			// System.out.print("Informe os dados do Fornecedor: " + "\n" + "1)CNPJ: ");
			// Fornecedor fornecedor1 = new Fornecedor();
			// CNPJ = in.nextLine();
			// System.out.println("2)Nome da empresa: ");
			// empresaFornecedor = in.next();
			//
			// // inserindo os dados do fornecedor
			// fornecedor1.setCNPJ(CNPJ);
			// fornecedor1.setNomeEmpresa(empresaFornecedor);
			//
			// // tentando inserir o fornecedor no Repositorio do tipo Lista
			// NegocioFornecedor nF = new NegocioFornecedor(tipoRepositorio);
			//
			// // antes de inserir o fornecedor, temos que verificar se ele ja existe na
			// Lista
			// try {
			// nF.acessoProcurar(cpfMenu);// usuario tentara encontrar fornecedor pelo CPF
			// digitado no menu
			// } catch (FornecedorNaoEncontradoException exc) {
			// exc.printStackTrace();
			// }

		} // end - fornecedor

		// no caso em que escolher a Entrega, os negocios e metodos da ENTREGA deve
		// estar nesse IF
		else if (tipoAcesso.equalsIgnoreCase("E")) {
			int opcao = 0;
			Fachada cli = new Fachada("C");
			Fachada ent = new Fachada(tipoAcesso);
			while (opcao != 5) {
				System.out.println("Escolha uma op��o abaixo:");
				System.out.println("1) Caso deseje fazer um pedido para entrega"); // inserir
				System.out.println("2) Caso deseje remover um pedido de entrega"); // remover
				System.out.println("3) Caso deseje atualizar uma entrega"); // atualizar
				System.out.println("4) Caso deseje verificar se esse pedido j� foi feito"); // procurar
				System.out.println("5) Caso deseje finalizar a��o");
				opcao = in.nextInt();
				if (opcao == 1) {
					System.out.println("Digite o nome:");
					String nome = in.nextLine();
					System.out.println("Digite o cpf:");
					String cpf = in.nextLine();
					System.out.println("Digite o endere�o:");
					String endereco = in.nextLine();
					Cliente a = new Cliente(nome, cpf, endereco);
//					try {
						if (cli.temPessoaCliente(nome, cpf, endereco)) {
							System.out.println("Digite o pedido:");
							String pedido = in.nextLine();
							Entrega entrega = new Entrega(a, pedido);
							try {
								ent.Inserir(entrega);
							} catch (EntregaJaCadastradaException OI) {
								System.out.println(OI.getMessage());
							}
						}
//					} catch (ClienteNaoEncontradoException OI) {
//						System.out.println(OI.getMessage());
//					}
					
				} else if (opcao == 2) {
					System.out.println("Digite o nome:");
					String nome = in.nextLine();
					System.out.println("Digite o cpf:");
					String cpf = in.nextLine();
					System.out.println("Digite o endere�o:");
					String endereco = in.nextLine();
					Cliente a = new Cliente(nome, cpf, endereco);
					System.out.println("Digite o pedido:");
					String pedido = in.nextLine();
					Entrega b = new Entrega(a, pedido);
					try {
						ent.Remover(b);
						System.out.println("Entrega removida");
					} catch (EntregaNaoEncontradaException OI) {
						System.out.println(OI.getMessage());
					}
				} else if (opcao == 3) {
					System.out.println("Digite o nome:");
					String nome = in.nextLine();
					System.out.println("Digite o cpf:");
					String cpf = in.nextLine();
					System.out.println("Digite o endere�o:");
					String endereco = in.nextLine();
					Cliente a = new Cliente(nome, cpf, endereco);
					System.out.println("Digite o novo pedido:");
					String pedido = in.nextLine();
					Entrega b = new Entrega(a, pedido);
					try {
						ent.Atualizar(b);
						System.out.println("Entrega atualizada.");
					} catch (EntregaNaoEncontradaException OI) {
						System.out.println(OI.getMessage());
					}
				} else if (opcao == 4) {
					System.out.println("Digite o nome:");
					String nome = in.nextLine();
					System.out.println("Digite o cpf:");
					String cpf = in.nextLine();
					System.out.println("Digite o endere�o:");
					String endereco = in.nextLine();
					Cliente a = new Cliente(nome, cpf, endereco);
					System.out.println("Digite o pedido que deseja verificar:");
					String pedido = in.nextLine();
					Entrega b = new Entrega(a, pedido);
					if (ent.Procurar(b)) {
						System.out.println("Pedido de entrega j� foi feito");
					} else {
						System.out.println(
								"Pedido de entrega n�o foi feito, caso deseje realizar um pedido, selecione '1)");
					}
				} else if (opcao == 5) {
					System.out.println("Opera��o finalizada");
				} else {
					System.out.println("Por favor, digite 1) 2) 3) 4) ou 5)");
				}
			} // end - entrega
		}
	}
}