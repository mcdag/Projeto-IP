package Interfaces;

import ClassesBasicas.Produto;
import Excecoes.ProdutoNaoEncontradoException;
import Excecoes.ProdutoJaCadastradoException;

public interface InterfaceProduto {
	public void inserir(Produto novoProduto) throws ProdutoJaCadastradoException;

	public void remover(int codigoProduto) throws ProdutoNaoEncontradoException;

	public void atualizarNome(int codigoProduto, String novoNome) throws ProdutoNaoEncontradoException;

	public void atualizarPreco(int codigoProduto, Double novoPreco) throws ProdutoNaoEncontradoException;

	public boolean procurar(int codigoProduto) throws ProdutoNaoEncontradoException;
}
