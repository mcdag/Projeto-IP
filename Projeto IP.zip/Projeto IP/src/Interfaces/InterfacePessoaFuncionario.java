package Interfaces;

import ClassesBasicas.Funcionario;
import Excecoes.FuncionarioNaoEncontradoException;

public interface InterfacePessoaFuncionario {
	abstract void inserirPessoaFuncionario(Funcionario funcionario);

	abstract void removerPessoaFuncionario(Funcionario funcionario) throws FuncionarioNaoEncontradoException;

	abstract boolean temPessoaFuncionario(Funcionario funcionario);

	abstract Funcionario buscarPessoaFuncionario(String cpf , int i) throws FuncionarioNaoEncontradoException;

	abstract void atualizarNomePessoaFuncionario(String nome, String cpf) throws FuncionarioNaoEncontradoException;

	abstract void atualizarSalarioPessoaFuncionario(double salario, String cpf) throws FuncionarioNaoEncontradoException;
}