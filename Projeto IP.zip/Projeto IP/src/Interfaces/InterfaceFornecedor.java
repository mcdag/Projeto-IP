package Interfaces;

import ClassesBasicas.Fornecedor;
import Excecoes.CnpjInvalidoException;
import Excecoes.FornecedorJaCadastradoException;
import Excecoes.FornecedorNaoEncontradoException;

public interface InterfaceFornecedor {
	// metodos que ambos reposit�rios(lista e array) ter�o:
	public void inserir(Fornecedor fornecedor) throws FornecedorJaCadastradoException;

	public void remover(String CNPJ) throws CnpjInvalidoException;

	public boolean procurar(String CNPJ) throws FornecedorNaoEncontradoException;

	public void atualizar(Fornecedor fornecedor);
}
