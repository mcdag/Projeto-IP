package Interfaces;

import ClassesBasicas.Entrega;
import Excecoes.EntregaNaoEncontradaException;
import Excecoes.EntregaJaCadastradaException;
import ClassesBasicas.Cliente;

public interface InterfaceEntrega {
	abstract void inserirEntrega(Entrega entrega) throws EntregaJaCadastradaException;

	abstract void removerEntrega(Entrega entrega) throws EntregaNaoEncontradaException;

	abstract void atualizarEntrega(Entrega entrega) throws EntregaNaoEncontradaException;

	abstract boolean procurarEntrega(Entrega entrega);
}