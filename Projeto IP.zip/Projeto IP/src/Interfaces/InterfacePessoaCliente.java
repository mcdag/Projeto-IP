package Interfaces;

import ClassesBasicas.Cliente;
import Excecoes.ClienteNaoEncontradoException;

public interface InterfacePessoaCliente {
	abstract void inserirPessoaCliente(Cliente cliente);

	abstract void removerPessoaCliente(Cliente cliente) throws ClienteNaoEncontradoException;

	abstract boolean temPessoaCliente(Cliente cliente);

	abstract Cliente buscarPessoaCliente(String cpf , int i) throws ClienteNaoEncontradoException;

	abstract void atualizarNomePessoaCliente(String nome, String cpf) throws ClienteNaoEncontradoException;

	abstract void atualizarEnderecoPessoaCliente(String endereco, String cpf) throws ClienteNaoEncontradoException;
}