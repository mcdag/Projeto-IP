package Fachada;

import Interfaces.*;
import Negocios.*;
import ClassesBasicas.*;
import Excecoes.*;

public class Fachada {
	private NegocioProduto negocioProduto;
	private NegocioFornecedor negocioFornecedor;
	private NegocioEntrega negocioEntrega;
	private NegocioPessoa negocioPessoa;

	public Fachada(String letra) {
		this.negocioProduto = new NegocioProduto(letra);
		this.negocioFornecedor = new NegocioFornecedor(letra);
		this.negocioEntrega = new NegocioEntrega(letra);
		// 'this.negocioPessoa = new NegocioPessoa(letra);
	}

	public void procurar(int codigoProduto) throws ProdutoNaoEncontradoException {
		this.negocioProduto.procurar(codigoProduto);
	}

	public void inserir(Produto item) throws ProdutoJaCadastradoException {
		this.negocioProduto.inserir(item);
	}

	public void remover(int codigoProduto) throws ProdutoNaoEncontradoException {
		this.negocioProduto.remover(codigoProduto);
	}

	public void atualizarNome(int codigoProduto, String novoNome) throws ProdutoNaoEncontradoException {
		this.negocioProduto.atualizarNome(codigoProduto, novoNome);
	}

	public void atualizarPreco(int codigoProduto, Double novoPreco) throws ProdutoNaoEncontradoException {
		this.negocioProduto.atualizarPreco(codigoProduto, novoPreco);
	}

	public void acessoInserir(Fornecedor fornecedor) throws FornecedorJaCadastradoException {
		this.negocioFornecedor.acessoInserir(fornecedor);
	}

	public void acessoRemover(String CNPJ) throws CnpjInvalidoException {
		this.negocioFornecedor.acessoRemover(CNPJ);
	}

	public void acessoAtualizar(Fornecedor fornecedor) {
		this.negocioFornecedor.acessoAtualizar(fornecedor);
	}

	public void acessoProcurar(String CNPJ) throws FornecedorNaoEncontradoException {
		this.negocioFornecedor.acessoProcurar(CNPJ);
	}

	public void Inserir(Entrega entrega) throws EntregaJaCadastradaException {
		this.negocioEntrega.inserir(entrega);
	}

	public void Remover(Entrega entrega) throws EntregaNaoEncontradaException {
		this.negocioEntrega.remover(entrega);
	}

	public void Atualizar(Entrega entrega) throws EntregaNaoEncontradaException {
		this.negocioEntrega.atualizar(entrega);
	}

	public boolean Procurar(Entrega entrega) {
		if (this.negocioEntrega.procurar(entrega)) {
			return true;
		}
		return false;
	}

	public void cadastrarCliente(String nome, String cpf, String endereco) throws ClienteJaCadastradoException {
		this.negocioPessoa.cadastrarCliente(nome, cpf, endereco);
	}

	public void encerrarCadastroCliente(String cpf) throws ClienteNaoEncontradoException {
		this.negocioPessoa.encerrarCadastroCliente(cpf);
	}

	public void atualizarNomeCliente(String nome, String cpf) throws ClienteNaoEncontradoException {
		this.negocioPessoa.atualizarNomeCliente(nome, cpf);
	}

	public void atualizarEnderecoCliente(String endereco, String cpf) throws ClienteNaoEncontradoException {
		this.negocioPessoa.atualizarEnderecoCliente(endereco, cpf);
	}

	public void contratarFuncionario(String nome, String cpf, double salario) throws FuncionarioJaContratadoException {
		this.negocioPessoa.contratarFuncionario(nome, cpf, salario);
	}

	public void demitirFuncionario(String cpf) throws FuncionarioNaoEncontradoException {
		this.negocioPessoa.demitirFuncionario(cpf);
	}

	public void atualizarNomeFuncionario(String nome, String cpf) throws FuncionarioNaoEncontradoException {
		this.negocioPessoa.atualizarNomeFuncionario(nome, cpf);
	}

	public void atualizarSalarioFuncionario(double salario, String cpf) throws FuncionarioNaoEncontradoException {
		this.negocioPessoa.atualizarSalarioFuncionario(salario, cpf);
	}

	public boolean temPessoaCliente(String nome, String cpf, String endereco) {
		if (this.negocioPessoa.temCliente(nome, cpf, endereco)) {
			return true;
		}
		return false;
	}
	// insiram aqui todos os metodos da sua classe negocios.
}
