package Negocios;

import ClassesBasicas.Produto;
import Excecoes.ProdutoJaCadastradoException;
import Excecoes.ProdutoNaoEncontradoException;
import Interfaces.*;
import Repositorios.RepositorioArrayProduto;
import Repositorios.RepositorioListaProduto;

public class NegocioProduto {
	private InterfaceProduto repositorio;

	public NegocioProduto(String escolhaRepositorio) {
		if (escolhaRepositorio.equalsIgnoreCase("a")) {
			repositorio = (InterfaceProduto) new RepositorioArrayProduto();

		} else if (escolhaRepositorio.equalsIgnoreCase("l")) {
			repositorio = new RepositorioListaProduto();
		}
	}

	public void procurar(int codigoProduto) throws ProdutoNaoEncontradoException {
		repositorio.procurar(codigoProduto);
	}

	public void inserir(Produto item) throws ProdutoJaCadastradoException {
		repositorio.inserir(item);
	}

	public void remover(int codigoProduto) throws ProdutoNaoEncontradoException {
		repositorio.remover(codigoProduto);
	}

	public void atualizarNome(int codigoProduto, String novoNome) throws ProdutoNaoEncontradoException {
		repositorio.atualizarNome(codigoProduto, novoNome);
	}

	public void atualizarPreco(int codigoProduto, Double novoPreco) throws ProdutoNaoEncontradoException {
		repositorio.atualizarPreco(codigoProduto, novoPreco);
	}
}
