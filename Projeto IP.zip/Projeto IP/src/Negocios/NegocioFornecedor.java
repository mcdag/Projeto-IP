package Negocios;

import Interfaces.InterfaceFornecedor;
import Repositorios.RepositorioArrayFornecedor;
import Repositorios.RepositorioListaFornecedor;
import ClassesBasicas.Fornecedor;
import Excecoes.CnpjInvalidoException;
import Excecoes.FornecedorJaCadastradoException;
import Excecoes.FornecedorNaoEncontradoException;

public class NegocioFornecedor {
	private InterfaceFornecedor repositorio;

	public NegocioFornecedor(String letraRepositorio) {// construtor
		if (letraRepositorio.equalsIgnoreCase("a")) {// usuario escolheu trabalhar com array
			repositorio = new RepositorioArrayFornecedor();

		} else if (letraRepositorio.equalsIgnoreCase("l")) {// usario escolheu lista
			repositorio = new RepositorioListaFornecedor();
		}
	}// end - construtor

	public void acessoInserir(Fornecedor fornecedor) throws FornecedorJaCadastradoException {
		repositorio.inserir(fornecedor);
	}

	public void acessoRemover(String CNPJ) throws CnpjInvalidoException {
		repositorio.remover(CNPJ);
	}

	public void acessoAtualizar(Fornecedor fornecedor) {
		repositorio.atualizar(fornecedor);
	}

	public void acessoProcurar(String CNPJ) throws FornecedorNaoEncontradoException {
		repositorio.procurar(CNPJ);
	}
}// end - negocioFornecedor
