package Negocios;
import ClassesBasicas.Cliente;
import ClassesBasicas.Funcionario;
import Interfaces.InterfacePessoaCliente;
import Interfaces.InterfacePessoaFuncionario;
import Excecoes.ClienteJaCadastradoException;
import Excecoes.FuncionarioNaoEncontradoException;
import Excecoes.ClienteNaoEncontradoException;
import Excecoes.FuncionarioJaContratadoException;
import Repositorios.RepositorioArrayPessoaCliente;
import Repositorios.RepositorioArrayPessoasFuncionario;
import Repositorios.RepositorioListaPessoaCliente;
import Repositorios.RepositorioListaPessoaFuncionario;
import Excecoes.ErroDeInicializacaoException;

public class NegocioPessoa {
    private InterfacePessoaCliente repositorioClientes;
    private InterfacePessoaFuncionario repositorioFuncionario;
    public NegocioPessoa(String letra) throws ErroDeInicializacaoException{
        if(letra.equals("a")) {
        	this.repositorioCliente = new RepositorioArrayPessoaCliente();
        	this.repositorioFuncionario = new RepositorioArrayPessoaFuncionario();
        }else if(letra.equals("l")) {
        	this.repositorioCliente = new RepositorioListaPessoaCliente();
        	this.repositorioFuncionario = new RepositorioListaPessoaFuncionario();
        }else {
        	throw new ErroDeInicializacaoException();
        }
    }
    public void cadastrarCliente (String nome,String cpf,String endereco) throws ClienteJaCadastradoException{
        Cliente cliente = new Cliente(nome,cpf,endereco);
        if(!this.repositorioCliente.temPessoaCliente(cliente)){
            this.repositorioCliente.inserirPessoaCliente(cliente);
        }else{
            throw new ClienteJaCadastradoException();
        }
    }
    public void encerrarCadastroCliente (String cpf) throws ClienteNaoEncontradoException{
        Cliente cliente = this.repositorioCliente.buscarPessoaCliente(cpf,0);
        this.repositorioCliente.removerPessoaCliente(cliente);
    }
    public void atualizarNomeCliente(String nome,String cpf) throws ClienteNaoEncontradoException{
        Clientes cliente = this.repositorioCliente.buscarPessoaCliente(cpf, 0);
        cliente.setNomePessoa(nome);
    }
    public void atualizarEnderecoCliente(String endereco,String cpf)throws ClienteNaoEncontradoException {
    	Clientes cliente = this.repositorioCliente.buscarPessoaCliente(cpf, 0);
    	cliente.setEnderecoCliente(endereco);
    }
    public void contratarFuncionario(String nome,String cpf,double salario) throws FuncionarioJaContratadoException{
    	Funcionarios funcionario = new Funcionario(nome,cpf,salario);
    	if(!this.repositorioFuncionario.temPessoaFuncionario(funcionario)) {
    		this.repositorioFuncionario.inserirPessoaFuncionario(funcionario);
    	}else {
    		throw new FuncionarioJaContratadoException();
    	}
    }
    public void demitirFuncionario(String cpf)throws FuncionarioNaoEncontradoException{
    	Funcionarios funcionario = this.repositorioFuncionarios.buscarPessoaFuncionario(cpf, 0);
    	this.repositorioFuncionarios.removerPessoaFuncionario(funcionario);
    }
    public void atualizarNomeFuncionario(String nome,String cpf) throws FuncionarioNaoEncontradoException{
    	Funcionarios funcionario = this.repositorioFuncionarios.buscarPessoaFuncionario(cpf, 0);
    	funcionario.setNomePessoa(nome);
    }
    public void atualizarSalarioFuncionario(double salario,String cpf) throws FuncionarioNaoEncontradoException{
    	Funcionarios funcionario = this.repositorioFuncionarios.buscarPessoaFuncionario(cpf, 0);
    	funcionario.setSalarioFuncionario(salario);
    }
    
    public boolean temCliente (String nome, String cpf, String endereco) {
    	Cliente cliente = this.repositorioClientes(nome, cpf, endereco);
    	if(this.repositorioClientes.temPessoaCliente(cliente)) {
    		return true;
    	}
    	return false;
    }
}