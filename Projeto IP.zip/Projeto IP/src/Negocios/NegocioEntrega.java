package Negocios;

import Interfaces.InterfaceEntrega;
import Repositorios.RepositorioArrayEntrega;
import Repositorios.RepositorioListaEntrega;
import ClassesBasicas.Entrega;
import Excecoes.EntregaJaCadastradaException;
import Excecoes.EntregaNaoEncontradaException;

public class NegocioEntrega {
	private InterfaceEntrega repositorio;

	public NegocioEntrega(String qualRepositorio) {
		if (qualRepositorio.equalsIgnoreCase("a")) {
			repositorio = (InterfaceEntrega) new RepositorioArrayEntrega();

		} else if (qualRepositorio.equalsIgnoreCase("l")) {
			repositorio = new RepositorioListaEntrega(qualRepositorio);
		}
	}

	public void inserir(Entrega entrega) throws EntregaJaCadastradaException {
		repositorio.inserirEntrega(entrega);
	}

	public void remover(Entrega entrega) throws EntregaNaoEncontradaException {
		repositorio.removerEntrega(entrega);
	}

	public void atualizar(Entrega entrega) throws EntregaNaoEncontradaException {
		repositorio.atualizarEntrega(entrega);
	}

	public boolean procurar(Entrega entrega){
		if(repositorio.procurarEntrega(entrega)) {
			return true;
		}
		return false;
	}
}
