package Excecoes;

public class FornecedorJaCadastradoException extends Exception {
	public FornecedorJaCadastradoException(String CNPJ) {
		super("Fornecedor com CNPJ: " + CNPJ + "j� foi cadastrado");
	}
}
