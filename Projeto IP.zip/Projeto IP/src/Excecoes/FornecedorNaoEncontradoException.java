package Excecoes;

public class FornecedorNaoEncontradoException extends Exception {
	public FornecedorNaoEncontradoException(String CNPJ) {
		super("CNPJ invalido: " + CNPJ);
	}
}
