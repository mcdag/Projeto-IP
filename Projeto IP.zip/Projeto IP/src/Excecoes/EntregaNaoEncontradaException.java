package Excecoes;

public class EntregaNaoEncontradaException extends Exception {
	public EntregaNaoEncontradaException() {
		super("Entrega n�o encontrada.");
	}
}