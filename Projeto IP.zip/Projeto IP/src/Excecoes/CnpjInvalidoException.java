package Excecoes;

public class CnpjInvalidoException extends Exception {
	public CnpjInvalidoException(String CNPJ) {
		super("CNPJ inv�lido: " + CNPJ);
	}
}
