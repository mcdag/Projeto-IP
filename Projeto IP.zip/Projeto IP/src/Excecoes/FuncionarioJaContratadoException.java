package Excecoes;

public class FuncionarioJaContratadoException extends Exception {
	public FuncionarioJaContratadoException() {
		super("Funcionario ja contratado");
	}
}