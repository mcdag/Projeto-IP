package Excecoes;

public class ProdutoNaoEncontradoException extends Exception {
	public ProdutoNaoEncontradoException(int codigoProduto) {
		super("Este produto nao foi encontrado em nosso sistema.");
	}
}
