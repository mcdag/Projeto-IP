package Excecoes;

public class OpcaoInvalidaException extends Exception {
	public OpcaoInvalidaException(String letra) {
		super("Opcao invalida. Digite a letra 'L' ou a letra 'A'.");
	}
}
