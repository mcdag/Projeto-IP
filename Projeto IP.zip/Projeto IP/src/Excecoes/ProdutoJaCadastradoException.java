package Excecoes;

public class ProdutoJaCadastradoException extends Exception {
	public ProdutoJaCadastradoException(int codigoProduto) {
		super("Este produto j� est� cadastrado em nosso sistema.");
	}
}
