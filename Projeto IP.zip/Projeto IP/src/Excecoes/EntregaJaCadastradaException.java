package Excecoes;

public class EntregaJaCadastradaException extends Exception {
	public EntregaJaCadastradaException() {
		super("Entrega j� cadastrada");
	}
}
